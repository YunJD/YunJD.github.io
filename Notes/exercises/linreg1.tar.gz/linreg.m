gdescent;
t = [0;0];
x = load('ex2x.dat');
y = load('ex2y.dat');

figure
plot(x, y, 'o');
ylabel('Height in meters')
xlabel('Age in years')

x = gradOrdLeastSquaresPrep(x, y);
t = gradientDescent(t, x, y, 0.07, @gradOrdLeastSquares);

hold on
plot(x(:,2), x * t, '-');
legend('Training data', 'Linear regression')

disp(t)

printf('Height at age 3.5: %f\n', t(1) + t(2) * 3.5);
printf('Height at age 7: %f\n', t(1) + t(2) * 7.0);
