x = load('ex2x.dat');
y = load('ex2y.dat');

figure
plot(x, y, 'o');
ylabel('Height in meters')
xlabel('Age in years')
