% Not a function file
1;

% Dammit, making classes in this is so unintuitive

function prep = gradOrdLeastSquaresPrep (x, y)
	prep = [ones(length(y), 1), x]
endfunction

% This computes the gradient for the ordinary least squares to determine coefficients 
function grad = gradOrdLeastSquares (t, x, y)
	% By multiplying x transpose at the beginning, the desired sum is actually produced
	grad = x' * (x * t - y) / length(y);
endfunction




function coefficients = gradDescStep (t, a, grad)
	coefficients = t - a * grad;
endfunction

function t = gradientDescent(t0, x, y, a, fGrad)
	t = t0;

	grad = fGrad(t, x, y)

	while any(abs(grad) > 1e-7)
		t = gradDescStep(t, a, grad);
		grad = fGrad(t, x, y)
	endwhile
endfunction
