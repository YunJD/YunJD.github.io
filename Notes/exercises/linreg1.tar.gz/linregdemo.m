x = load('ex2x.dat')
y = load('ex2y.dat')

J_vals = zeros(20, 20);   % initialize Jvals to 100x100 matrix of 0's
theta0_vals = linspace(-3, 3, 20);
theta1_vals = linspace(-1, 1, 20);
for i = 1:length(theta0_vals)
	  for j = 1:length(theta1_vals)
	  t = [theta0_vals(i); theta1_vals(j)];
	  J_vals(i,j) = sum((t(1) + t(2) * x - y).^2)/length(y)
    end
end

% Plot the surface plot
% Because of the way meshgrids work in the surf command, we need to 
% transpose J_vals before calling surf, or else the axes will be flipped
J_vals = J_vals'
figure;
surf(theta0_vals, theta1_vals, J_vals)
xlabel('\theta_0'); ylabel('\theta_1')
