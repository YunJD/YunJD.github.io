gdescent;

alpha = 1.0;

steps = 100000;

x = load('ex3x.dat');
y = load('ex3y.dat');

m = length(y);

% Normalize data

sigma = std(x);
mu = mean(x);

x(:,1) = (x(:,1) - mu(1))./sigma(1);
x(:,2) = (x(:,2) - mu(2))./sigma(2);
x = [ones(m, 1), x];

theta = zeros(size(x(1,:)))';
grad = [1];

i = 0;
while any(abs(grad) > 1e-7) && i < steps
	grad = gradOrdLeastSquares(theta, x, y);
	theta = theta - alpha * grad;
	++i;
end

disp("Steps: "), disp(i);
disp("Theta: "), disp(theta);

feat = [1, (1650 - mu(1))/sigma(1), ((3 - mu(2))/sigma(2))];
disp("Price of a house with 1650 sq ft and 3 bedrooms:"), disp(feat * theta);
