gdescent;

alpha1 = 0.19;
alpha2 = 1.0;
alpha3 = 1.3;

steps = 100

x = load('ex3x.dat');
y = load('ex3y.dat');

m = length(y)

% Normalize data

sigma = std(x)
mu = mean(x)

x(:,1) = (x(:,1) - mu(1))./sigma(1);
x(:,2) = (x(:,2) - mu(2))./sigma(2);
x = [ones(m, 1), x]

theta1 = zeros(size(x(1,:)))';
theta2 = zeros(size(x(1,:)))';
theta3 = zeros(size(x(1,:)))';
J1 = zeros(steps, 1);
J2 = zeros(steps, 1);
J3 = zeros(steps, 1);

for iter = 1:steps
	diff1 = x * theta1 - y
	diff2 = x * theta2 - y
	diff3 = x * theta3 - y

	J1(iter) = (0.5 / m) .* (diff1' * diff1)
	J2(iter) = (0.5 / m) .* (diff2' * diff2)
	J3(iter) = (0.5 / m) .* (diff3' * diff3)
	theta1 = theta1 - alpha1 .* gradOrdLeastSquares(theta1, x, y)
	theta2 = theta2 - alpha2 .* gradOrdLeastSquares(theta2, x, y)
	theta3 = theta3 - alpha3 .* gradOrdLeastSquares(theta3, x, y)
end

% plot J

figure;
plot(0:(steps - 1), J1(1:steps), 'r-');
hold on;
plot(0:(steps - 1), J2(1:steps), 'g-');
plot(0:(steps - 1), J3(1:steps), 'b-');
xlabel('Number of iterations')
ylabel('Cost of J')
