% Not a function file
1;

% Dammit, making classes in this is so unintuitive
% This computes the gradient for the ordinary least squares to determine coefficients 
function grad = gradOrdLeastSquares (t, x, y)
	% By multiplying x transpose at the beginning, the desired sum is actually produced
	grad = x' * (x * t - y) ./ length(y);
endfunction
