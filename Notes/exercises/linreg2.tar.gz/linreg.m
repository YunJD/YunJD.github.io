gdescent;

alpha = 1.0;

steps = 100000;

x = load('ex3x.dat');
y = load('ex3y.dat');

m = length(y);

x = [ones(m, 1), x]

theta = inv(x' * x) * x' * y

disp("Theta:"), disp(theta)
feat = [1, 1650, 3]

disp("Predicting the price of a house with 1650 squared ft and 3 bedrooms:"), disp(feat * theta);
